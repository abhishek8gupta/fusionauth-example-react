const { v4: generateId } = require('uuid');

const { NotFoundError } = require('../util/errors');
const { readData, writeData } = require('./util');

async function getAll() {
  const storedData = await readData();
  if (!storedData.tdumps) {
    throw new NotFoundError('Could not find any thread dumps.');
  }
  return storedData.tdumps;
}

async function get(id) {
  const storedData = await readData();
  if (!storedData.tdumps || storedData.tdumps.length === 0) {
    throw new NotFoundError('Could not find any thread dumps.');
  }

  const tdump = storedData.tdumps.find((td) => td.id === id);
  if (!tdump) {
    throw new NotFoundError('Could not find thread dump for id ' + id);
  }

  return tdump;
}

async function add(data) {
  const storedData = await readData();
  storedData.tdumps.unshift({ ...data, id: generateId() });
  await writeData(storedData);
}

async function replace(id, data) {
  const storedData = await readData();
  if (!storedData.tdumps || storedData.tdumps.length === 0) {
    throw new NotFoundError('Could not find any thread dumps.');
  }

  const index = storedData.tdumps.findIndex((ev) => ev.id === id);
  if (index < 0) {
    throw new NotFoundError('Could not find thread dump for id ' + id);
  }

  storedData.tdumps[index] = { ...data, id };

  await writeData(storedData);
}

async function remove(id) {
  const storedData = await readData();
  const updatedData = storedData.tdumps.filter((ev) => ev.id !== id);
  await writeData({ ...storedData, tdumps: updatedData });
}

exports.getAll = getAll;
exports.get = get;
exports.add = add;
exports.replace = replace;
exports.remove = remove;
