const express = require('express');

const { getAll, get, add, replace, remove } = require('../data/tdump');
const { checkAuth } = require('../util/auth');
const {
  isValidText,
  isValidDate,
  isValidImageUrl,
} = require('../util/validation');

const router = express.Router();

router.get('/', async (req, res, next) => {
  console.log(req.token);
  try {
    const tdumps = await getAll();
    res.json({ tdumps: tdumps });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const tdump = await get(req.params.id);
    res.json({ tdump: tdump });
  } catch (error) {
    next(error);
  }
});

router.use(checkAuth);

router.post('/', async (req, res, next) => {
  console.log(req.token);
  const data = req.body;

  let errors = {};

  if (!isValidText(data.title)) {
    errors.title = 'Invalid title.';
  }

  if (!isValidText(data.content)) {
    errors.title = 'Invalid content.';
  }

  const filecontent = data.content;
  delete data.content;

  console.log("filecontent " + filecontent);
  console.log("filename " + data.title);

  try {
    await add(data);
    res.status(201).json({ message: 'Thread dump saved.', tdump: data });
    console.log("erroThread dump saved.  ");
  } catch (error) {
    console.log("error " + error);
    next(error);
  }
});

router.patch('/:id', async (req, res, next) => {
  const data = req.body;

  let errors = {};

  if (!isValidText(data.title)) {
    errors.title = 'Invalid title.';
  }

  if (!isValidText(data.description)) {
    errors.description = 'Invalid description.';
  }

  if (!isValidDate(data.date)) {
    errors.date = 'Invalid date.';
  }

  if (!isValidImageUrl(data.image)) {
    errors.image = 'Invalid image.';
  }

  if (Object.keys(errors).length > 0) {
    return res.status(422).json({
      message: 'Updating the thread dump failed due to validation errors.',
      errors,
    });
  }

  try {
    await replace(req.params.id, data);
    res.json({ message: 'Thread dump updated.', tdump: data });
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', async (req, res, next) => {
  try {
    await remove(req.params.id);
    res.json({ message: 'Thread dump deleted.' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
