import {
  Form,
  useNavigate,
  useNavigation,
  useActionData,
  json,
  redirect
} from 'react-router-dom';

import { useForm } from 'react-hook-form';
import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';

import classes from './EventForm.module.css';
import { getAuthToken } from '../util/auth';

function TdumpForm({ method, tdump }) {
  ////
  const { register, handleSubmit } = useForm();
  const [uploadedFiles, setUploadedFiles] = useState([]);

  const onDrop = useCallback((acceptedFiles) => {
    setUploadedFiles(acceptedFiles);
  }, []);

  const onSubmit = async (data) => {
    // Handle form submission with additional form data and uploaded files
    const formData = new FormData();
      formData.append('title', data.title);

      // Append uploaded files to FormData
      uploadedFiles.forEach((file, index) => {
        formData.append(`file${index + 1}`, file);
      });

    console.log('Data: ' + data);
    console.log('Form Data: ' + formData);
    console.log('Form Data: file ' + formData.get('file1'));
    console.log('Form Data: title: ', formData.get('title'));
    // console.log('Uploaded Files:', uploadedFiles);
    setUploadedFiles([]);

    navigate('..'); 
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: 'image/*', // Specify accepted file types, for example, only images
  });

  ////
  const data = useActionData();
  const navigate = useNavigate();
  const navigation = useNavigation();

  const isSubmitting = navigation.state === 'submitting';

  function cancelHandler() {
    navigate('..');
  }

  return (
    <Form method={method} className={classes.form} onSubmit={onSubmit}>
      {data && data.errors && (
        <ul>
          {Object.values(data.errors).map((err) => (
            <li key={err}>{err}</li>
          ))}
        </ul>
      )}
      <p>
        <label htmlFor="title">Title</label>
        <input type="text" id="title" {...register('title')} />
      </p>
      {/* Dropzone for file uploads */}
      <div {...getRootProps()} style={dropzoneStyles}>
        <input {...getInputProps()}/>

        {isDragActive ? (
          <p>Drop the files here ...</p>
        ) : (
          <p>Drag 'n' drop some files here, or click to select files</p>
        )}
      </div>

      {/* Display uploaded files */}
      {uploadedFiles.length > 0 && (
        <div>
          <h4>Selected Files:</h4>
          <ul>
            {uploadedFiles.map((file, index) => (
              <li key={index}>{file.name}</li>
            ))}
          </ul>
        </div>
      )}

      {/* <button type="submit">Submit</button> */}
      <div className={classes.actions}>
        <button type="button" onClick={cancelHandler} disabled={isSubmitting}>
          Cancel
        </button>
        <button disabled={isSubmitting} type="submit">
          {isSubmitting ? 'Submitting...' : 'Save'}
        </button>
      </div>
    </Form>
  );
}

const dropzoneStyles = {
  border: '2px dashed #cccccc',
  borderRadius: '4px',
  padding: '20px',
  textAlign: 'center',
  cursor: 'pointer',
  margin: '20px',
};

export default TdumpForm;

export async function action({ request, params }) {
  const method = request.method;
  const data = await request.formData();

  console.log("********* data.get('title'): " + data.get('title'));
  console.log("********* data.get('uploadedFile'): " + data.get('uploadedFile'));
  const tdumpData = {
    title: data.get('title'),
    image: data.get('image'),
    date: data.get('date'),
    description: data.get('description'),
  };

  let url = 'http://localhost:8080/tdumps';

  if (method === 'PATCH') {
    const tdumpId = params.tdumpId;
    url = 'http://localhost:8080/tdumps/' + tdumpId;
  }

  const token = getAuthToken();

  const response = await fetch(url, {
    method: method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + token
    },
    body: JSON.stringify(tdumpData),
  });

  if (response.status === 422) {
    return response;
  }

  if (!response.ok) {
    throw json({ message: 'Could not save thread dump.' }, { status: 500 });
  }

  return redirect('/tdumps');
}

