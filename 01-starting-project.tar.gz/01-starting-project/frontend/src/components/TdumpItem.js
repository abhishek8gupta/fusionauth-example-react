import { Link, useSubmit, useRouteLoaderData } from 'react-router-dom';

import classes from './EventItem.module.css';

function TdumpItem({ tdump }) {
  const token = useRouteLoaderData('root');
  const submit = useSubmit();

  function startDeleteHandler() {
    const proceed = window.confirm('Are you sure?');

    if (proceed) {
      submit(null, { method: 'delete' });
    }
  }

  return (
    <article className={classes.event}>
      <img src={tdump.image} alt={tdump.title} />
      <h1>{tdump.title}</h1>
      <time>{tdump.date}</time>
      <p>{tdump.description}</p>
      {token && (
        <menu className={classes.actions}>
          <Link to="edit">Edit</Link>
          <button onClick={startDeleteHandler}>Delete</button>
        </menu>
      )}
    </article>
  );
}

export default TdumpItem;
