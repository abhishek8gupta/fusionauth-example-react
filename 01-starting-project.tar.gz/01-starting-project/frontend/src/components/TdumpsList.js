// import { useLoaderData } from 'react-router-dom';
import { Link } from 'react-router-dom';

import classes from './EventsList.module.css';

function TdumpsList({tdumps}) {
  return (
    <div className={classes.events}>
      <h1>All Thread Dumps</h1>
      <ul className={classes.list}>
        {tdumps.map((tdump) => (
          <li key={tdump.id} className={classes.item}>
            <Link to={`/tdumps/${tdump.id}`}>
              <img src={tdump.image} alt={tdump.title} />
              <div className={classes.content}>
                <h2>{tdump.title}</h2>
                <time>{tdump.date}</time>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TdumpsList;
