import { NavLink, useRouteLoaderData } from 'react-router-dom';

import classes from './EventsNavigation.module.css';

function TdumpsNavigation() {
  const token = useRouteLoaderData('root');

  return (
    <header className={classes.header}>
      <nav>
        <ul className={classes.list}>
          <li>
            <NavLink
              to="/tdumps"
              className={({ isActive }) =>
                isActive ? classes.active : undefined
              }
              end
            >
              All ThreadDumps
            </NavLink>
          </li>
          {token && (
          <li>
            <NavLink
              to="/tdumps/new"
              className={({ isActive }) =>
                isActive ? classes.active : undefined
              }
            >
              New ThreadDump
            </NavLink>
          </li>
          )}
        </ul>
      </nav>
    </header>
  );
}

export default TdumpsNavigation;
