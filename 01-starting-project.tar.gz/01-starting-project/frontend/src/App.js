import { RouterProvider, createBrowserRouter } from 'react-router-dom';

import EditEventPage from './pages/EditEvent';
import ErrorPage from './pages/Error';
import EventDetailPage, {
  loader as eventDetailLoader,
  action as deleteEventAction,
} from './pages/EventDetail';
import EventsPage, { loader as eventsLoader } from './pages/Events';
import EventsRootLayout from './pages/EventsRoot';
import HomePage from './pages/Home';
import NewEventPage from './pages/NewEvent';
import RootLayout from './pages/Root';
import { action as manipulateEventAction } from './components/EventForm';
import NewsletterPage, { action as newsletterAction } from './pages/Newsletter';
import AuthenticationPage, {action as authAction} from './pages/Authentication';
import {action as logoutAction} from './pages/Logout';
import {tokenLoader, checkAuthLoader}  from './util/auth';

// thread dumps
import TdumpsRootLayout from './pages/TdumpsRootLayout';
import TdumpsPage, { loader as tdumpsLoader } from './pages/Tdumps';
import NewTdumpPage from './pages/NewTdump';
import TdumpDetailPage, {
  loader as tdumpDetailLoader,
  action as deleteTdumpAction,
} from './pages/TdumpDetail';

import { action as manipulateTdumpAction } from './components/TdumpForm';
import EditTdumpPage from './pages/EditTdump';

const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    errorElement: <ErrorPage />,
    id: 'root',
    loader: tokenLoader,
    children: [
      { index: true, element: <HomePage /> },
      {
        path: 'events',
        element: <EventsRootLayout />,
        children: [
          {
            index: true,
            element: <EventsPage />,
            loader: eventsLoader,
          },
          {
            path: ':eventId',
            id: 'event-detail',
            loader: eventDetailLoader,
            children: [
              {
                index: true,
                element: <EventDetailPage />,
                action: deleteEventAction,
              },
              {
                path: 'edit',
                element: <EditEventPage />,
                action: manipulateEventAction,
                loader: checkAuthLoader
              },
            ],
          },
          {
            path: 'new',
            element: <NewEventPage />,
            action: manipulateEventAction,
            loader: checkAuthLoader
          },
        ],
      },
      {
        path: 'tdumps',
        element: <TdumpsRootLayout />,
        children: [
          {
            index: true,
            element: <TdumpsPage />,
            loader: tdumpsLoader,
          },
          {
            path: ':tdumpId',
            id: 'tdump-detail',
            loader: tdumpDetailLoader,
            children: [
              {
                index: true,
                element: <TdumpDetailPage />,
                action: deleteTdumpAction,
              },
              {
                path: 'edit',
                element: <EditTdumpPage />,
                action: manipulateTdumpAction,
                loader: checkAuthLoader
              },
            ],
          },
          {
            path: 'new',
            element: <NewTdumpPage />,
            action: manipulateTdumpAction,
            loader: checkAuthLoader
          },
        ],
      },
      {
        path: 'newsletter',
        element: <NewsletterPage />,
        action: newsletterAction,
      },
      {
        path: 'auth',
        element: <AuthenticationPage />,
        action: authAction
      },
      {
        path: 'logout',
        action: logoutAction
      },
    ],
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
