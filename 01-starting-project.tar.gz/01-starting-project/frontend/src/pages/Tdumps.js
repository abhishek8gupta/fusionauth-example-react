import { Suspense } from 'react';
import { useLoaderData, json, defer, Await } from 'react-router-dom';

import TdumpsList from '../components/TdumpsList';

function TdumpsPage() {
  const { tdumps } = useLoaderData();

  return (
    <Suspense fallback={<p style={{ textAlign: 'center' }}>Loading...</p>}>
      <Await resolve={tdumps}>
        {(loadedTdumps) => <TdumpsList tdumps={loadedTdumps} />}
      </Await>
    </Suspense>
  );
}

export default TdumpsPage;

async function loadThreadDumps() {
  const response = await fetch('http://localhost:8080/tdumps');

  if (!response.ok) {
    throw json(
      { message: 'Could not fetch thread dumps.' },
      {
        status: 500,
      }
    );
  } else {
    const resData = await response.json();
    return resData.tdumps;
  }
}

export function loader() {
  return defer({
    tdumps: loadThreadDumps(),
  });
}
