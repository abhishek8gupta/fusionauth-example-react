import PageContent from '../components/PageContent';

function HomePage() {
  return (
    <PageContent title="Welcome!">
      <p>Browse for our amazing analysis of thread dumps!</p>
    </PageContent>
  );
}

export default HomePage;
