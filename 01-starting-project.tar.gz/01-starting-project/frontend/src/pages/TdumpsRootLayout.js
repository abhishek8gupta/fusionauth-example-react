import { Outlet } from 'react-router-dom';

import TdumpsNavigation from '../components/TdumpsNavigation';

function TdumpsRootLayout() {
  return (
    <>
      <TdumpsNavigation />
      <Outlet />
    </>
  );
}

export default TdumpsRootLayout;
