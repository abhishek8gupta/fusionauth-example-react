import { Suspense } from 'react';
import {
  useRouteLoaderData,
  json,
  redirect,
  defer,
  Await,
} from 'react-router-dom';

import TdumpItem from '../components/TdumpItem';
import TdumpsList from '../components/TdumpsList';
import { getAuthToken } from '../util/auth';

function TdumpDetailPage() {
  const { tdump, tdumps } = useRouteLoaderData('tdump-detail');

  return (
    <>
      <Suspense fallback={<p style={{ textAlign: 'center' }}>Loading...</p>}>
        <Await resolve={tdump}>
          {(loadedTdump) => <TdumpItem tdump={loadedTdump} />}
        </Await>
      </Suspense>
      <Suspense fallback={<p style={{ textAlign: 'center' }}>Loading...</p>}>
        <Await resolve={tdumps}>
          {(loadedTdumps) => <TdumpsList tdumps={loadedTdumps} />}
        </Await>
      </Suspense>
    </>
  );
}

export default TdumpDetailPage;

async function loadTdump(id) {
  const response = await fetch('http://localhost:8080/tdumps/' + id);

  if (!response.ok) {
    throw json(
      { message: 'Could not fetch details for selected event.' },
      {
        status: 500,
      }
    );
  } else {
    const resData = await response.json();
    return resData.tdump;
  }
}

async function loadTdumps() {
  const response = await fetch('http://localhost:8080/tdumps');

  if (!response.ok) {
    throw json(
      { message: 'Could not fetch events.' },
      {
        status: 500,
      }
    );
  } else {
    const resData = await response.json();
    return resData.tdumps;
  }
}

export async function loader({ request, params }) {
  const id = params.tdumpId;

  return defer({
    tdump: await loadTdump(id),
    tdumps: loadTdumps(),
  });
}

export async function action({ params, request }) {
  const tdumpId = params.tdumpId;
  const token = getAuthToken();
  const response = await fetch('http://localhost:8080/tdumps/' + tdumpId, {
    method: request.method,
    headers: {
      'Authorization': 'Bearer ' + token
    }
  });

  if (!response.ok) {
    throw json(
      { message: 'Could not delete event.' },
      {
        status: 500,
      }
    );
  }
  return redirect('/tdumps');
}
