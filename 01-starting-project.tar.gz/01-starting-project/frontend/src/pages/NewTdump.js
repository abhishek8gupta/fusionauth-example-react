import TdumpForm from '../components/TdumpForm';

function NewTdumpPage() {
  return <TdumpForm method="post" />;
}

export default NewTdumpPage;

