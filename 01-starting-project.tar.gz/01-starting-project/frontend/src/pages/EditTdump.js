import { useRouteLoaderData } from 'react-router-dom';

import TdumpForm from '../components/TdumpForm';

function EditTdumpPage() {
  const data = useRouteLoaderData('tdump-detail');

  return <TdumpForm method="patch" tdump={data.tdump} />;
}

export default EditTdumpPage;
